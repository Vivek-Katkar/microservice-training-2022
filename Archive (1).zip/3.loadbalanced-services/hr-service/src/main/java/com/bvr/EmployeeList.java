package com.bvr;

import java.util.List;

public class EmployeeList {

	public EmployeeList() {
		// TODO Auto-generated constructor stub
	}
	
	private List<Employee> employees;

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
	
	

}
