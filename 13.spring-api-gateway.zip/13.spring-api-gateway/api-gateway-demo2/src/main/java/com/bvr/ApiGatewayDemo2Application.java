package com.bvr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGatewayDemo2Application {

	public static void main(String[] args) {
		SpringApplication.run(ApiGatewayDemo2Application.class, args);
	}

}
