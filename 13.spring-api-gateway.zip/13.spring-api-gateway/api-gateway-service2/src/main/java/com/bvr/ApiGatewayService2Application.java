package com.bvr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGatewayService2Application {

	public static void main(String[] args) {
		SpringApplication.run(ApiGatewayService2Application.class, args);
	}

}
